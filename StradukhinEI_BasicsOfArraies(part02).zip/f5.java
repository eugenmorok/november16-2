public class f5 {
    public static void main(String[] args) {

        int a = -2147483648-1;
        int b = -127;

        System.out.println();
        System.out.println(Integer.toBinaryString(a));
        System.out.println(a + "\n.......");


        System.out.println(Integer.toBinaryString(b));

    }
}
